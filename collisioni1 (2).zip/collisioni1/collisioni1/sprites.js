var running = [
    "https://i.ibb.co/RpdRrL75/Run-000.png", 
    "https://i.ibb.co/rKLMnzZ5/Run-001.png",
    "https://i.ibb.co/Lz9Z4p74/Run-002.png",
    "https://i.ibb.co/mVnCfjC6/Run-003.png",
    "https://i.ibb.co/mVnCfjC6/Run-004.png",
];

