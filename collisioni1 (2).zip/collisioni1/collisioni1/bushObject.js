var bushObject = {
  width: 100,
  height: 50,
  x: 100,
  y: 270 - 50,
  tryX: 0,
  tryY: 0,
  
  loadImages: function() {
      this.image = new Image(this.width, this.height);
      this.image.src = "https://i.ibb.co/CPdHYdB/Bush-1.png";
      
    },
  };  